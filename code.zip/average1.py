# Input marks for each subject
english_marks = float(input("Enter marks for English: "))
math_marks = float(input("Enter marks for Math: "))
science_marks = float(input("Enter marks for Science: "))

# Calculate the total marks
total_marks = english_marks + math_marks + science_marks

# Calculate the average
average_marks = total_marks / 3

# Print the result
print(f"The average marks across English, Math, and Science is: {average_marks:.2f}")