class TreeNode:
    def __init__(self, value):
        self.value = value
        self.children = []

    def add_child(self, child_node):
        self.children.append(child_node)

# Create root node
root = TreeNode(1)

# Create child nodes
child1 = TreeNode(2)
child2 = TreeNode(3)

# Add child nodes to root
root.add_child(child1)
root.add_child(child2)

# Add grandchild nodes
child1.add_child(TreeNode(4))
child1.add_child(TreeNode(5))

child2.add_child(TreeNode(6))

# Print the tree structure
def print_tree(node, level=0):
    print(' ' * level * 4 + f"- {node.value}")
    for child in node.children:
        print_tree(child, level + 1)

print_tree(root)
