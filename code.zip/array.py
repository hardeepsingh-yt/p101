# Define an empty array (list) with 3 elements
my_array = [0, 0, 0]

# Read values one by one
my_array[0] = input("Enter first element: ")
my_array[1] = input("Enter second element: ")
my_array[2] = input("Enter third element: ")

# Print the array
print("The array is:", my_array)