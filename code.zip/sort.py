list = []

while True:
    num = int(input("Enter number (0 to end) => "))
    if num == 0:
        break
    list.append(num)

for i in range(len(list)-1):
    for j in range(i+1,len(list)):
        if list[i]>list[j]:
            temp = list[i]
            list[i] = list[j]
            list[j] = temp

print(list)
