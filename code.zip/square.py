def square(x):
    # Base case: x^2 = 1 when x = 1
    if x == 1:
        return 1
    # Recursive case: f(x) = f(x-1) + 2x - 1
    return square(x - 1) + 2 * x - 1

# Test the function
x = int(input("Enter a number: "))
result = square(x)
print(f"{x}^2 = {result}")
