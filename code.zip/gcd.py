def gcd_two_numbers(a, b):
    if b == 0:
        return a
    return gcd_two_numbers(b, a % b)

def gcd_of_list(numbers, n):
    if n == 1:
        return numbers[0]
    return gcd_two_numbers(gcd_of_list(numbers, n - 1), numbers[n - 1])

numbers = list(map(int, input("Enter the numbers (space-separated): ").split()))
result = gcd_of_list(numbers, len(numbers))
print(f"GCD of the numbers is: {result}")
