from abc import ABC, abstractmethod

# Component (Base Coffee Interface)
class Coffee(ABC):
    @abstractmethod
    def cost(self):
        pass
    
    @abstractmethod
    def description(self):
        pass

# Concrete Component (Basic Coffee)
class SimpleCoffee(Coffee):
    def cost(self):
        return 5  # Base price of the coffee
    
    def description(self):
        return "Simple Coffee"

# Decorator (Abstract Decorator)
class CoffeeDecorator(Coffee):
    def __init__(self, coffee: Coffee):
        self._coffee = coffee

    @abstractmethod
    def cost(self):
        pass
    
    @abstractmethod
    def description(self):
        pass

# Concrete Decorators
class MilkDecorator(CoffeeDecorator):
    def cost(self):
        return self._coffee.cost() + 2  # Adding milk costs 2 more
    
    def description(self):
        return self._coffee.description() + ", Milk"

class SugarDecorator(CoffeeDecorator):
    def cost(self):
        return self._coffee.cost() + 1  # Adding sugar costs 1 more
    
    def description(self):
        return self._coffee.description() + ", Sugar"

# Client Code
# Order a simple coffee
coffee = SimpleCoffee()
print(f"{coffee.description()} costs: ${coffee.cost()}")

# Add milk to the coffee
coffee_with_milk = MilkDecorator(coffee)
print(f"{coffee_with_milk.description()} costs: ${coffee_with_milk.cost()}")

# Add sugar to the coffee with milk
coffee_with_milk_and_sugar = SugarDecorator(coffee_with_milk)
print(f"{coffee_with_milk_and_sugar.description()} costs: ${coffee_with_milk_and_sugar.cost()}")
