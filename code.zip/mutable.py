def modifier(number, string, list1, list2):
    number = 5
    string = "Goodbye"
    list1 = [4, 5, 6]
    list2.append(10)
    print("Inside:", number, string, list1, list2)


number = 1
string = "Hello"
list1 = [1, 2, 3]
list2 = [1, 2, 3]

print("Before:", number, string, list1, list2)
modifier(number, string, list1, list2) 
print("After:", number, string, list1, list2)
