import random

class DatabaseConnection:
    def execute_query(self, query):
        print("Here we execute")
    
class ConnectionPool:
    _max_connections = 20
    _connections = []
    
    @classmethod
    def get_connection(cls):
        if len(cls._connections) < cls._max_connections:
            connection = DatabaseConnection()
            cls._connections.append(connection)
        else:
            connection = random.choice(cls._connections)
        return(connection)
        
connection1 = ConnectionPool.get_connection()
connection2 = ConnectionPool.get_connection()

connection1.execute_query("select * from table")
connection2.execute_query("insert into table values(1,2)")