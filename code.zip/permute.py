def permute(s, l, pref=""):
    if l > 1:
        for i in range(l):
            ch = s[i]
            rest = s[:i] + s[i+1:]
            permute(rest, l-1, pref + ch)
    else:
        print(pref + s)

# Input
s = input("Please enter a string to permute-> ")
permute(s, len(s))
