import re
import math

def generate_prime_lookup():
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101]
    return dict( zip('abcdefghijklmnopqrstuvwxyz', primes) )

def word_to_product(word, prime_lookup):
    return math.prod(prime_lookup[char] for char in word)

def clean_word(word):
    return re.sub(r'[^a-zA-Z]', '', word).lower()

def unjumble_word(jumbled_word, words_file):
    prime_lookup = generate_prime_lookup()
    cleaned_word = clean_word(jumbled_word)
    target_product = word_to_product(cleaned_word, prime_lookup)

    with open(words_file, 'r') as file:
        for line in file:
            word = line.strip()
            if word_to_product(clean_word(word), prime_lookup) == target_product:
                return word

    return "No match found"

# Example usage
jumbled_word = input("Enter the jumbled word: ")
words_file = "words.txt"  # Make sure this file exists in the same directory as your script

result = unjumble_word(jumbled_word, words_file)
print(f"Unjumbled word: {result}")