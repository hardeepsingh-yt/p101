# cross-platform number reading routine, better than Python's built in one
# Works on Linux, MacOS and Windows
# USP: does not allow user to enter non-numeric letters. If a user hits character
#      keys, they are neither displayed nor considered

import sys

# Cross-platform character capture
if sys.platform == "win32":
    import msvcrt
else:
    import termios
    import tty

def get_char():
    if sys.platform == "win32":
        return msvcrt.getch().decode('utf-8')  # Read single character on Windows
    else:
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch

def read_number():
    allowed_chars = set("0123456789.+-")
    input_str = ""

    while True:
        ch = get_char()
        
        # Handle Enter (finish input)
        if ch == "\r" or ch == "\n":
            print("")  # Move to the next line in console after input is complete
            return input_str if input_str else None
        
        # Handle backspace
        elif ch == "\x7f" or ch == "\b":  # Handle backspace for both Unix and Windows
            if input_str:
                input_str = input_str[:-1]
                sys.stdout.write("\b \b")  # Erase the last character in the console
                sys.stdout.flush()
        
        # Handle allowed input
        elif ch in allowed_chars:
            sys.stdout.write(ch)  # Print the valid character to console
            sys.stdout.flush()
            input_str += ch

# Example of usage
if __name__ == "__main__":
    print("Enter a number:")
    number = read_number()
    print(f"Final input: {number}")
