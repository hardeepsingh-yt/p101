import threading
import random
import time

class Employee:
    def __init__(self, employee_id, salary):
        self.employee_id = employee_id
        self.salary = salary
        self.threadID = None  # Acts as a lock

    def lock_employee(self, thread_id):
        if self.threadID is None:
            self.threadID = thread_id
            return True
        return False

    def release_employee(self, thread_id):
        # Release the lock by setting threadID to None
        if (self.threadID == thread_id):
            self.threadID = None
            return True
        else:
            return False

    def update_salary(self, increment_rate):
        self.salary += self.salary * increment_rate

class SalaryUpdater(threading.Thread):
    def __init__(self, employees, start_index, thread_id):
        threading.Thread.__init__(self)
        self.employees = employees
        self.start_index = start_index
        self.thread_id = thread_id

    def run(self):
        for i in range(self.start_index, self.start_index + 10):
            employee = self.employees[i]
            # Attempt to lock the employee
            if employee.lock_employee(self.thread_id):
                print(f"Thread {self.thread_id} updating Employee {employee.employee_id}")
                # Update salary by 10%
                employee.update_salary(0.1)
                time.sleep(0.1)  # simulate time taken for the operation
                # Release employee lock
                employee.release_employee(self.thread_id)
                print(f"Thread {self.thread_id} released Employee {employee.employee_id}")
            else:
                print(f"Thread {self.thread_id} could not lock Employee {employee.employee_id}")

# Initialize 100 employees with random salaries between 30k and 100k
employees = [Employee(employee_id=i, salary=random.randint(30000, 100000)) for i in range(100)]

# Create and start 10 threads, each handling 10 employees
threads = []
for i in range(10):
    thread = SalaryUpdater(employees, start_index=i * 10, thread_id=i + 1)
    threads.append(thread)
    thread.start()

# Wait for all threads to finish
for thread in threads:
    thread.join()

# Display the updated salaries
for emp in employees:
    print(f"Employee ID: {emp.employee_id}, Updated Salary: {emp.salary}")
