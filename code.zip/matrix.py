# Function to input marks and calculate average per subject
def calculate_averages(n):
    # Initialize nx5 matrix to store marks of n students in 5 subjects
    marks = []
    
    # Input marks for each student
    for i in range(n):
        print(f"Enter marks for student {i+1} in 5 subjects (space-separated):")
        student_marks = list(map(int, input().split()))
        marks.append(student_marks)
    
    # Initialize a list to store total marks for each subject
    subject_totals = [0] * 5

    # Calculate total marks for each subject
    for student in marks:
        for j in range(5):
            subject_totals[j] += student[j]

    # Calculate and print average marks for each subject
    print("\nAverage marks for each subject:")
    for j in range(5):
        print(f"Subject {j+1}: {subject_totals[j] / n:.2f}")

# Input number of students
n = int(input("Enter the number of students: "))

# Call the function to calculate averages
calculate_averages(n)
