def calculate_total_price(prices, tax_rate):
    total = 0
    for price in prices:
        total += price

    total = total * (1 + tax_rate)

    return total

prices = [10, 20, 30]  
tax_rate = 0.1         
print(f"Total price: {calculate_total_price(prices, tax_rate)}")
