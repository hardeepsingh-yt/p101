from abc import ABC, abstractmethod

# Component Interface
class FileSystemComponent(ABC):
    @abstractmethod
    def display(self, indent=0):
        pass

# Leaf (File)
class File(FileSystemComponent):
    def __init__(self, name):
        self.name = name
    
    def display(self, indent=0):
        print(' ' * indent + f"- File: {self.name}")

# Composite (Folder)
class Folder(FileSystemComponent):
    def __init__(self, name):
        self.name = name
        self.children = []
    
    def add(self, component: FileSystemComponent):
        self.children.append(component)
    
    def remove(self, component: FileSystemComponent):
        self.children.remove(component)
    
    def display(self, indent=0):
        print(' ' * indent + f"+ Folder: {self.name}")
        for child in self.children:
            child.display(indent + 2)

# Client code
# Create files
file1 = File("file1.txt")
file2 = File("file2.txt")
file3 = File("file3.txt")

# Create folders
folder1 = Folder("Documents")
folder2 = Folder("Music")
folder3 = Folder("Projects")

# Build the composite structure
folder1.add(file1)      # Add file1 to Documents
folder1.add(folder3)    # Add Projects folder to Documents
folder3.add(file2)      # Add file2 to Projects
folder2.add(file3)      # Add file3 to Music

# Display the file structure
print("File System Structure:")
folder1.display()       # Displays contents of Documents
folder2.display()       # Displays contents of Music
