# Ask for the number of subjects
num_subjects = int(input("How many subjects? "))

# Initialize an empty list to store marks
marks_list = []

# Loop to get marks for each subject and store them in the list
for i in range(num_subjects):
    marks = float(input(f"Enter marks for subject {i + 1}: "))
    marks_list.append(marks)

# Initialize total_marks to 0
total_marks = 0

# Loop to calculate the total marks
for marks in marks_list:
    total_marks += marks

# Calculate the average
average_marks = total_marks / num_subjects

# Print the result
print(f"The average marks across {num_subjects} subjects is: {average_marks:.2f}")
