import re

# Original sentence
text = "We spent .50 dollars in drinks, .85 dollars in clothes."

# Regular expression to match patterns like .50, .85, etc.
pattern = r'(\D)(\.\d+)'

# Replace pattern by adding '0' before the decimal
corrected_text = re.sub(pattern, r'\1 0\2', text)

# Print corrected sentence
print(corrected_text)
