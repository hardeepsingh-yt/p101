from abc import ABC, abstractmethod

# Abstract handler (Approver)
class Approver(ABC):
    def __init__(self):
        self.next_approver = None

    def set_next_approver(self, approver):
        self.next_approver = approver

    @abstractmethod
    def approve_expense(self, amount):
        pass

# Concrete handler (TeamLead)
class TeamLead(Approver):
    def approve_expense(self, amount):
        if amount <= 1000:
            print(f"Team Lead: Approved expense of ${amount}")
        elif self.next_approver:
            print(f"Team Lead: Can't approve ${amount}, forwarding to Department Head.")
            self.next_approver.approve_expense(amount)

# Concrete handler (DepartmentHead)
class DepartmentHead(Approver):
    def approve_expense(self, amount):
        if amount <= 5000:
            print(f"Department Head: Approved expense of ${amount}")
        elif self.next_approver:
            print(f"Department Head: Can't approve ${amount}, forwarding to Executive.")
            self.next_approver.approve_expense(amount)

# Concrete handler (Executive)
class Executive(Approver):
    def approve_expense(self, amount):
        if amount > 5000:
            print(f"Executive: Approved expense of ${amount}")
        else:
            print(f"Executive: Invalid expense of ${amount}.")

# Client code
def main():
    # Create the chain of approvers
    team_lead = TeamLead()
    department_head = DepartmentHead()
    executive = Executive()

    team_lead.set_next_approver(department_head)
    department_head.set_next_approver(executive)

    # Test expenses
    expenses = [500, 2000, 7000]

    for expense in expenses:
        print(f"\nRequesting approval for expense of ${expense}...")
        team_lead.approve_expense(expense)

if __name__ == "__main__":
    main()
