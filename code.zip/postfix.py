def evaluate_postfix(expression):
    # Stack to store operands
    stack = []
    
    # Split the expression by spaces
    tokens = expression.split()
    
    for token in tokens:
        if token.isdigit():
            # If the token is an operand, push it onto the stack
            stack.append(int(token))
        else:
            # If the token is an operator, pop two operands from the stack
            right = stack.pop()
            left = stack.pop()
            
            # Perform the operation and push the result back onto the stack
            if token == '+':
                stack.append(left + right)
            elif token == '-':
                stack.append(left - right)
            elif token == '*':
                stack.append(left * right)
            elif token == '/':
                stack.append(left / right)
    
    # The result is the last item remaining on the stack
    return stack.pop()

# Input: Postfix expression as a string
expression = input("Enter a postfix expression: ")

# Evaluate the postfix expression and print the result
result = evaluate_postfix(expression)
print(f"Result: {result}")
