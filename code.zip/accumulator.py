# Initialize a variable to store the sum
total_sum = 0

# Read the first number outside the loop
number = int(input("Enter a number (0 to stop): "))

# Start the while loop
while number != 0:
    # Add the entered number to the total sum using a = a + b
    total_sum = total_sum + number
    
    # Read the next number
    number = int(input("Enter a number (0 to stop): "))

# Print the total sum of all entered numbers
print("The total sum is:", total_sum)
