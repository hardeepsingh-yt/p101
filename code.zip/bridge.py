# Implementor Interface
class DrawingTool:
    def draw_shape(self, shape):
        pass

# Concrete Implementors
class VectorGraphics(DrawingTool):
    def draw_shape(self, shape):
        print(f"Drawing {shape} using Vector Graphics")

class RasterGraphics(DrawingTool):
    def draw_shape(self, shape):
        print(f"Drawing {shape} using Raster Graphics")

# Abstraction
class Shape:
    def __init__(self, drawing_tool: DrawingTool):
        self.drawing_tool = drawing_tool
    
    def draw(self):
        pass

# Concrete Abstraction 1
class Circle(Shape):
    def __init__(self, drawing_tool: DrawingTool, radius: float):
        super().__init__(drawing_tool)
        self.radius = radius
    
    def draw(self):
        print(f"Circle with radius {self.radius}")
        self.drawing_tool.draw_shape("Circle")

# Concrete Abstraction 2
class Square(Shape):
    def __init__(self, drawing_tool: DrawingTool, side_length: float):
        super().__init__(drawing_tool)
        self.side_length = side_length
    
    def draw(self):
        print(f"Square with side length {self.side_length}")
        self.drawing_tool.draw_shape("Square")

# Client code
# Using Vector Graphics to draw shapes
vector_tool = VectorGraphics()
circle_with_vector = Circle(vector_tool, 5)
square_with_vector = Square(vector_tool, 3)

circle_with_vector.draw()
square_with_vector.draw()

# Using Raster Graphics to draw shapes
raster_tool = RasterGraphics()
circle_with_raster = Circle(raster_tool, 7)
square_with_raster = Square(raster_tool, 4)

circle_with_raster.draw()
square_with_raster.draw()
