import re

text = """
The quick brown jill@2cent.me jumped slyly over the lazy alice@2cent.me 
and asked it to pack box with five dozen jugs for jack@2cent.me.
Last one is simply a googly with @ but nothing before or after.
"""

pattern = r'([a-z0-9]+)@2cent\.me'

for match in re.finditer(pattern, text):
    alias = match.group(1)
    print(alias)
