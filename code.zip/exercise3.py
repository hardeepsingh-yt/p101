f = open('pad.txt', 'w')
f.write('0123456789abcdefghijklmnopqrstuvwxyz')
f.close()

f = open('pad.txt', 'r')
f.seek(12) # seek 12th position to read from 13th onwards
str = f.read(3)
print(str)

f.close()