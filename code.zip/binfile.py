import pickle
import sys

with open('input.dat', 'rb') as infile:
    num1 = pickle.load(infile)
    num2 = pickle.load(infile)

result = num1 + num2

sys.stdout.write(f"num1={num1} num2={num2} sum={result}\n")

with open('output.dat', 'wb') as outfile:
    pickle.dump(result, outfile)

