text = []

while True:
    inp = input(">")
    if inp == 'END':
        break
    text.append(inp + '\n') # Add newline to each line for writing to file

file = open("file.txt","w")
file.writelines(text)

for line in text:
    if line[0].isupper():
        print(line, end='') # Use end='' to avoid double newlines
        
file.close()