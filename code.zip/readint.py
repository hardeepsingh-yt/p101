def readint(prompt):
    while True:
        try:
            user_input = input(prompt)
            # Try to convert the input to float first, then take its integer part
            number = float(user_input)
            return int(number)
        except ValueError:
            # If conversion fails, the input is not a valid number
            print("Invalid input, please enter a valid number.")

# Usage
number = readint("Enter a number: ")
print(f"You entered: {number}")
