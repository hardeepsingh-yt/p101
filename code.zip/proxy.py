class Integer:
    def __init__(self, value):
        self.value = value

    def compare(self, other):
        return self.value > other.value


class IntegerProxy:
    def __init__(self):
        self.comparisons = 0

    def compare(self, a, b):
        self.comparisons += 1
        return a.compare(b)
        
    def get_comparisons(self):
        return self.comparisons


class BubbleSort:
    def __init__(self, comparator):
        self.comparator = comparator

    def sort(self, arr):
        n = len(arr)

        for i in range(n):
            for j in range(0, n - i - 1):
                if self.comparator.compare(arr[j], arr[j + 1]):
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]

        return arr


# Example usage
data = [64, 34, 25, 12, 22, 11, 90]
integer_objects = [Integer(x) for x in data]
proxy = IntegerProxy()
bubble_sort = BubbleSort(proxy)

sorted_data = bubble_sort.sort(integer_objects)
total_comparisons = proxy.get_comparisons()
sorted_values = [obj.value for obj in sorted_data]

print("Sorted array:", sorted_values)
print("Total comparisons:", total_comparisons)
