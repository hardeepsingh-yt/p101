from itertools import permutations

def is_valid_8_queens_solution(solution):
    if len(solution) != 8 or not solution.isdigit():
        return False

    positions = [(int(solution[i]), i + 1) for i in range(8)]
    rows = [pos[0] for pos in positions]
    cols = [pos[1] for pos in positions]

    if len(set(rows)) != 8 or len(set(cols)) != 8:
        return False

    diag1 = set()  # r - c
    diag2 = set()  # r + c

    for r, c in positions:
        if (r - c) in diag1 or (r + c) in diag2:
            return False
        diag1.add(r - c)
        diag2.add(r + c)

    return True

def generate_and_check_solutions():
    base_string = "12345678"
    for perm in permutations(base_string):
        solution = ''.join(perm)
        if is_valid_8_queens_solution(solution):
            print(f"Valid solution found: {solution}")
            cont = input("Do you want to find more solutions? (yes/no) => ").strip().lower()
            if cont != "yes":
                break

generate_and_check_solutions()
