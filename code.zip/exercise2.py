file = open('size.txt', 'r')
content = file.read()
print('Bytes = ', len(content))

file.seek(0)
lines = file.readlines()
print('Lines = ', len(lines))
file.close() # close the file as soon as its no longer needed

counter = 0
for line in lines:
    words = line.split()
    counter += len(words)
    
print('Words = ', counter)