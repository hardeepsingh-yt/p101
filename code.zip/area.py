pi = 3.1415

def area(radius):
    area = pi * radius * radius
    return area

print(area(4))
