print("Enter temperature in degrees Celsius:")
celsius = float(input())

# Convert Celsius to Fahrenheit
fahrenheit = (celsius * 9/5) + 32

# Display the result
print(f"{celsius}� Celsius is equal to {fahrenheit}� Fahrenheit.")
