import time

class Employee:
    def __init__(self, name):
        self.name = name
        self.total_hours = 0
        self.punch_in_time = None

    def punchIn(self):
        """Record the current time as the punch-in time."""
        self.punch_in_time = time.time()
        print(f"{self.name} punched in at {time.ctime(self.punch_in_time)}.")

    def punchOut(self):
        """Calculate hours worked and update total hours."""
        if self.punch_in_time is None:
            print(f"{self.name} hasn't punched in yet.")
            return

        punch_out_time = time.time()
        hours_worked = (punch_out_time - self.punch_in_time) / 3600  # Convert seconds to hours
        self.total_hours += hours_worked
        print(f"{self.name} punched out after {hours_worked:.2f} hours.")
        
        # Reset punch in time to None
        self.punch_in_time = None  

    def paySalary(self, hourly_rate):
        """Calculate and return the total salary based on hours worked."""
        salary = self.total_hours * hourly_rate
        print(f"{self.name}'s total salary: ${salary:.2f} for {self.total_hours:.2f} hours worked.")
        return salary

    def reset(self):
        """Reset all counters to zero."""
        self.total_hours = 0
        self.punch_in_time = None
        print(f"{self.name}'s records have been reset.")

# Example usage:
alice = Employee("Alice")

# Punching in
alice.punchIn()

# Simulate working for a bit (e.g., 2 seconds)
time.sleep(2)

# Punching out
alice.punchOut()

# Pay salary with an hourly rate
alice.paySalary(20)  # Example hourly rate of $20

# Reset the employee's records
alice.reset()
