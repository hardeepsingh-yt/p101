# Start with the first odd number
number = 1

# Loop indefinitely
while True:
    print(number)  # Print the current odd number
    number = number + 2  # Move to the next odd number
