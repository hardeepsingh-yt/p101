import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import os

class Email:
    def __init__(self):
        self.sender = None
        self.recipients = []
        self.subject = None
        self.body = None
        self.cc = []
        self.bcc = []
        self.attachments = []

class EmailBuilder:
    def __init__(self):
        self.email = Email()

    def set_sender(self, sender):
        self.email.sender = sender
        return self

    def add_recipient(self, recipient):
        self.email.recipients.append(recipient)
        return self

    def set_subject(self, subject):
        self.email.subject = subject
        return self

    def set_body(self, body):
        self.email.body = body
        return self

    def add_cc(self, cc):
        self.email.cc.append(cc)
        return self

    def add_bcc(self, bcc):
        self.email.bcc.append(bcc)
        return self

    def add_attachment(self, filepath):
        self.email.attachments.append(filepath)
        return self

    def build(self):
        return self.email

class EmailSender:
    def __init__(self, smtp_server, smtp_port, username, password):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.username = username
        self.password = password

    def send(self, email):
        msg = MIMEMultipart()
        msg['From'] = email.sender
        msg['To'] = ', '.join(email.recipients)
        msg['Subject'] = email.subject
        msg['Cc'] = ', '.join(email.cc)
        msg['Bcc'] = ', '.join(email.bcc)

        msg.attach(MIMEText(email.body, 'plain'))

        for filepath in email.attachments:
            part = MIMEBase('application', "octet-stream")
            with open(filepath, 'rb') as file:
                part.set_payload(file.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition',
                            'attachment; filename="{}"'.format(os.path.basename(filepath)))
            msg.attach(part)

        with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
            server.starttls()
            server.login(self.username, self.password)
            server.send_message(msg)

        print("Email sent successfully")

# Usage example
if __name__ == "__main__":
    builder = EmailBuilder()
    email = builder.set_sender("sender@example.com") \
                   .add_recipient("recipient@example.com") \
                   .set_subject("Test Email with Attachment") \
                   .set_body("This is a test email with an attachment.") \
                   .add_cc("cc@example.com") \
                   .add_attachment("./attachment.pdf") \
                   .build()

    sender = EmailSender("smtp.example.com", 587, "username", "password")
    sender.send(email)