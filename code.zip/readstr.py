# cross-platform string reading routine, better than Python's built in one
# Works on Linux, MacOS and Windows
# USP: allows for fixed length input. for example if length is set to 10
#      will not allow user to enter 11th character

import sys

# Cross-platform character capture
if sys.platform == "win32":
    import msvcrt
else:
    import termios
    import tty

def get_char():
    if sys.platform == "win32":
        return msvcrt.getch().decode('utf-8')  # Read single character on Windows
    else:
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch

def read_str(max_length):
    input_str = ""

    while True:
        ch = get_char()
        
        # Handle Enter (finish input)
        if ch == "\r" or ch == "\n":
            print("")  # Move to the next line in console after input is complete
            return input_str if input_str else None
        
        # Handle backspace
        elif ch == "\x7f" or ch == "\b":  # Handle backspace for both Unix and Windows
            if input_str:
                input_str = input_str[:-1]
                sys.stdout.write("\b \b")  # Erase the last character in the console
                sys.stdout.flush()
        
        # Handle allowed input
        elif len(input_str) < max_length:
            sys.stdout.write(ch)  # Print the valid character to console
            sys.stdout.flush()
            input_str += ch

        # Ignore additional characters once max_length is reached
        elif len(input_str) >= max_length:
            continue

# Example usage
if __name__ == "__main__":
    length = int(input("Enter the maximum length of the string: "))
    print(f"Enter a string (max {length} characters):")
    final_str = read_str(length)
    print(f"Final input: {final_str}")
