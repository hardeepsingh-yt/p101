file = open('filename.txt', 'r')
while True:
    line = file.readline()
    if not line:
        break
    print(line.strip())
file.close()
