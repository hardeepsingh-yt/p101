import time

def magic_trick(final_number):
    without_last_digit = final_number // 10
    original_number = without_last_digit - 1
    print("The number you were thinking of was:", original_number)

print("Think of a number between 1 and 20.")
time.sleep(3)

print("Multiply the number by 2.")
time.sleep(3)

print("Now add 2 to the result.")
time.sleep(3)

print("Multiply the result by 5.")
time.sleep(3)

print("Add 5 to the result.")
time.sleep(3)

print("Now, tell me the final number.")
final_number = int(input("Enter the final number: "))

magic_trick(final_number)
