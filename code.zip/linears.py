arr = list(map(int, input("Enter the list of numbers (space-separated): ").split()))
target = int(input("Enter the target number: "))

def linear_search(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1

index = linear_search(arr, target)

if index != -1:
    print(f"Target found at index {index}")
else:
    print("Target not found in the list")