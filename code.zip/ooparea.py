# Master class
class Shape:
    def calcArea(self):
        # Abstract method, just passing
        pass

# Square class
class Square(Shape):
    def calcArea(self, side):
        area = side ** 2
        print(f"Area of the square: {area}")

# Rectangle class
class Rectangle(Shape):
    def calcArea(self, length, breadth):
        area = length * breadth
        print(f"Area of the rectangle: {area}")

# Circle class
class Circle(Shape):
    def calcArea(self, radius):
        area = 3.14159 * radius ** 2
        print(f"Area of the circle: {area}")

# Creating shape instances and calculating areas
square = Square()
rectangle = Rectangle()
circle = Circle()

# Calculating areas by passing required parameters
square.calcArea(4)        # Output: Area of the square: 16
rectangle.calcArea(5, 3)  # Output: Area of the rectangle: 15
circle.calcArea(7)        # Output: Area of the circle: 153.93791
