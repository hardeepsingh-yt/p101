from abc import ABC, abstractmethod

# Observer Interface
class Observer(ABC):
    @abstractmethod
    def update(self, stock_name, stock_price):
        pass


# Subject (Stock)
class Stock:
    def __init__(self, name, price):
        self.name = name
        self.price = price
        self._observers = []

    def register_observer(self, observer):
        self._observers.append(observer)

    def remove_observer(self, observer):
        self._observers.remove(observer)

    def notify_observers(self):
        for observer in self._observers:
            observer.update(self.name, self.price)

    def set_price(self, new_price):
        print(f"\nSetting price of {self.name} to {new_price}")
        self.price = new_price
        self.notify_observers()


# Concrete Observer (Investor)
class Investor(Observer):
    def __init__(self, name):
        self.name = name

    # Implement the update method defined by the Observer interface
    def update(self, stock_name, stock_price):
        print(f"Investor {self.name} notified: {stock_name} is now {stock_price}")


# Usage
if __name__ == "__main__":
    # Create a stock (subject)
    amazon_stock = Stock("Amazon", 3000)

    # Create investors (observers)
    investor1 = Investor("Alice")
    investor2 = Investor("Bob")

    # Register investors to observe the stock
    amazon_stock.register_observer(investor1)
    amazon_stock.register_observer(investor2)

    # Change stock price and notify investors
    amazon_stock.set_price(3100)
    amazon_stock.set_price(3200)

    # Remove one observer and change the price again
    amazon_stock.remove_observer(investor1)
    amazon_stock.set_price(3300)
