import re

# URL to validate
url = "https://www.domain.com/path/folder/file.html"

# Regular expression to match and capture protocol, domain, path, and file
pattern = r'^(ftps|https|file)://([^/]+)(/.*/)?(.*)'

# Perform the match
match = re.match(pattern, url)

# Check if the URL is valid
if match:
    protocol = match.group(1)
    domain = match.group(2)
    path = match.group(3) if match.group(3) else '/'
    file = match.group(4)
    
    # Print the parts
    print(f"Protocol: {protocol}")
    print(f"Domain: {domain}")
    print(f"Path: {path}")
    print(f"File: {file}")
else:
    # If the URL is not valid, print "Not valid"
    print("Not valid")
