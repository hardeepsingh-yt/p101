# Define operator precedence
def precedence(op):
    if op == '+' or op == '-':
        return 1
    if op == '*' or op == '/':
        return 2
    return 0

# Function to perform infix to postfix conversion
def infix_to_postfix(expression):
    # Stack for operators and list for output
    stack = []
    output = []
    
    # Loop through each character in the infix expression
    i = 0
    while i < len(expression):
        char = expression[i]
        
        # If the character is a digit, add the entire number to the output
        if char.isdigit():
            num = []
            while i < len(expression) and expression[i].isdigit():
                num.append(expression[i])
                i += 1
            output.append(''.join(num))
            continue
        
        # If the character is an opening parenthesis, push it to the stack
        elif char == '(':
            stack.append('(')
        
        # If the character is a closing parenthesis, pop from stack to output until '(' is found
        elif char == ')':
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            stack.pop()  # Remove the '('
        
        # If the character is an operator
        else:
            # While the top of the stack has the same or greater precedence, pop from stack to output
            while stack and precedence(stack[-1]) >= precedence(char):
                output.append(stack.pop())
            stack.append(char)
        
        i += 1
    
    # Pop all the remaining operators in the stack to the output
    while stack:
        output.append(stack.pop())
    
    return ' '.join(output)

# Input: Infix expression as a string
expression = input("Enter an infix expression: ")

# Convert infix to postfix and print the result
postfix_expression = infix_to_postfix(expression)
print(f"Postfix Expression: {postfix_expression}")
