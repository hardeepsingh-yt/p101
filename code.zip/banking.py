balance = 1000  # Global variable to store the initial bank balance

def check_balance():
    print("Current balance:", balance)

def deposit(amount):
    global balance
    if amount > 0:
        balance += amount
        print(f"Deposited {amount}. New balance: {balance}")
    else:
        print("Invalid deposit amount. Please enter a positive value.")

def withdraw(amount):
    global balance
    if amount > 0 and amount <= balance:
        balance -= amount
        print(f"Withdrew {amount}. New balance: {balance}")
    else:
        print("Invalid withdraw amount. Please enter a value up to the current balance.")

def banking_system():
    while True:
        print("\nWelcome to the Banking System!")
        print("1. Check Balance")
        print("2. Deposit Money")
        print("3. Withdraw Money")
        print("4. Exit")
        
        choice = input("Enter your choice (1-4): ")
        
        if choice == '1':
            check_balance()
        elif choice == '2':
            amount = float(input("Enter the amount to deposit: "))
            deposit(amount)
        elif choice == '3':
            amount = float(input("Enter the amount to withdraw: "))
            withdraw(amount)
        elif choice == '4':
            print("Exiting the banking system. Thank you!")
            break
        else:
            print("Invalid choice. Please select a valid option.")

banking_system()
