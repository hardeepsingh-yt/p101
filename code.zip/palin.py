def is_palindrome(s):
    reversed_s = ''
    for char in s:
        reversed_s = char + reversed_s
    return s == reversed_s

# Ask the user to enter a string
original_string = input("Enter a string: ")

# Check if the string is a palindrome
if is_palindrome(original_string):
    print(f"{original_string} is a palindrome.")
else:
    print(f"{original_string} is not a palindrome.")
